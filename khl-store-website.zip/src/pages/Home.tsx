import heroEye from "/hero-eye.jpg";

const TELEGRAM_ORDER_LINK = "https://t.me/FARISKHL_BOT?start=WiJRSlcb";

const services = [
  {
    id: 1,
    icon: "📱",
    title: "PHONE APP",
    description: "اوصف تطبيقك و احصل عليه بسعر رمزي جداً",
  },
  {
    id: 2,
    icon: "🌐",
    title: "WEB APP",
    description: "اوصف موقعك الإلكتروني و احصل عليه بسعر رمزي جداً",
  },
  {
    id: 3,
    icon: "🤖",
    title: "BOTS",
    description: "اصنع بوتك الخاص على واتساب او تليجرام بحقوقك بسعر مذهل",
  },
  {
    id: 4,
    icon: "🔢",
    title: "FAKE NUMBER",
    description: "ارقام وهمية لتفعيل الحسابات و التطبيقات",
  },
];

const socialLinks = [
  {
    label: "TELEGRAM",
    icon: (
      <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
        <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.562 8.248l-2.01 9.47c-.15.67-.54.835-1.084.52l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12L6.18 14.765l-2.95-.92c-.64-.203-.654-.64.135-.948l11.497-4.432c.537-.194 1.006.131.7.783z"/>
      </svg>
    ),
    href: "https://t.me/FARIS_KHL",
    color: "rgba(0, 136, 204, 0.8)",
  },
  {
    label: "WHATSAPP",
    icon: (
      <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
      </svg>
    ),
    href: "https://wa.me/201117092028",
    color: "rgba(37, 211, 102, 0.8)",
  },
  {
    label: "FACEBOOK",
    icon: (
      <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
      </svg>
    ),
    href: "https://www.facebook.com/share/1JHvLAbgrw/",
    color: "rgba(24, 119, 242, 0.8)",
  },
  {
    label: "GMAIL",
    icon: (
      <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
        <path d="M24 5.457v13.909c0 .904-.732 1.636-1.636 1.636h-3.819V11.73L12 16.64l-6.545-4.91v9.273H1.636A1.636 1.636 0 0 1 0 19.366V5.457c0-2.023 2.309-3.178 3.927-1.964L5.455 4.64 12 9.548l6.545-4.91 1.528-1.145C21.69 2.28 24 3.434 24 5.457z"/>
      </svg>
    ),
    href: "mailto:faris.khl.dev@gmail.com",
    color: "rgba(234, 67, 53, 0.8)",
  },
];

export default function Home() {
  return (
    <div className="min-h-screen relative" style={{
        backgroundImage: "url('/bg.png')",
        backgroundSize: "cover",
        backgroundPosition: "center top",
        backgroundAttachment: "fixed",
        backgroundRepeat: "no-repeat",
      }}>
      {/* Dark overlay so text stays readable over bg */}
      <div style={{
        position: "fixed",
        inset: 0,
        background: "linear-gradient(180deg, rgba(0,0,0,0.72) 0%, rgba(5,0,0,0.65) 50%, rgba(0,0,0,0.80) 100%)",
        zIndex: 0,
        pointerEvents: "none",
      }} />
      <div className="scanline" />
      <div className="noise-overlay" />

      <div className="relative z-10">
        {/* Hero Section */}
        <section className="flex flex-col items-center justify-center pt-16 pb-10 px-4">
          {/* Hero Image */}
          <div className="hero-image-wrapper float-anim mb-8" style={{ width: 240, height: 240, borderRadius: "50%", overflow: "hidden" }}>
            <img
              src={heroEye}
              alt="KHL Store"
              style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }}
            />
          </div>

          {/* Store Name */}
          <h1
            className="text-center font-black title-glow flicker-anim mb-3"
            style={{
              fontSize: "clamp(1.6rem, 5vw, 2.8rem)",
              color: "#ff2020",
              letterSpacing: "0.05em",
              lineHeight: 1.2,
            }}
          >
            𓄂ᬼ𝑲.𝑯.𝑳_𝑺𝑻𝑶𝑹𝑬𒋨
          </h1>

          {/* Subtitle */}
          <p
            className="text-center mt-2 mb-8"
            style={{
              color: "#ccc",
              fontSize: "clamp(0.95rem, 3vw, 1.2rem)",
              textShadow: "0 0 10px rgba(220,20,20,0.4)",
              maxWidth: 480,
            }}
          >
            ⚡ اعظم موقع للخدمات الرقمية بأسعار رمزية ⚡
          </p>

          {/* Social Buttons */}
          <div className="flex flex-wrap justify-center gap-3 mb-2">
            {socialLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                target={link.href.startsWith("mailto") ? undefined : "_blank"}
                rel="noopener noreferrer"
                className="social-btn flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold"
                style={{ color: link.color, minWidth: 130 }}
              >
                {link.icon}
                <span>{link.label}</span>
              </a>
            ))}
          </div>
        </section>

        <div className="section-divider mx-auto" style={{ maxWidth: 600 }} />

        {/* Services Section */}
        <section className="py-14 px-4">
          <h2
            className="text-center font-black mb-12"
            style={{
              color: "#cc1010",
              fontSize: "clamp(1.3rem, 4vw, 2rem)",
              textShadow: "0 0 20px rgba(200,10,10,0.6)",
              letterSpacing: "0.12em",
            }}
          >
            ✦ خدماتنا ✦
          </h2>

          <div
            className="grid gap-6 mx-auto"
            style={{
              maxWidth: 900,
              gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            }}
          >
            {services.map((service) => (
              <div
                key={service.id}
                className="card-hover rounded-2xl p-6 flex flex-col items-center text-center"
              >
                <div
                  className="text-5xl mb-4"
                  style={{ filter: "drop-shadow(0 0 10px rgba(220,20,20,0.6))" }}
                >
                  {service.icon}
                </div>
                <h3
                  className="font-black mb-3 tracking-widest"
                  style={{
                    color: "#ff3030",
                    fontSize: "1.2rem",
                    textShadow: "0 0 10px rgba(220,20,20,0.5)",
                  }}
                >
                  {service.title}
                </h3>
                <p
                  className="mb-6 leading-relaxed"
                  style={{ color: "#bbb", fontSize: "0.95rem", lineHeight: 1.8 }}
                >
                  {service.description}
                </p>
                <a
                  href={TELEGRAM_ORDER_LINK}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-order w-full py-3 rounded-xl font-black text-white text-sm tracking-wide"
                  style={{ textDecoration: "none", display: "block" }}
                >
                  ♕ طلب الآن من تليجرام ♕
                </a>
              </div>
            ))}
          </div>
        </section>

        <div className="section-divider mx-auto" style={{ maxWidth: 600 }} />

        {/* Footer */}
        <footer
          className="text-center py-10 px-4"
          style={{ color: "#666", fontSize: "0.85rem" }}
        >
          <p style={{ color: "#883333", lineHeight: 1.8 }}>
            ♕ جميع الحقوق محفوظة ل FARIS K.H.L 2026 الشيطان الروسي ©
          </p>
        </footer>
      </div>
    </div>
  );
}
