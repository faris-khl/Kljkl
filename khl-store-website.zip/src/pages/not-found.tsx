export default function NotFound() {
  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center"
      style={{ background: "#050505", color: "#cc1010" }}
    >
      <h1
        className="font-black text-6xl mb-4"
        style={{ textShadow: "0 0 30px rgba(220,20,20,0.8)" }}
      >
        404
      </h1>
      <p style={{ color: "#888" }}>الصفحة غير موجودة</p>
      <a
        href="/"
        className="mt-6 px-6 py-3 rounded-lg font-bold"
        style={{ background: "#8b0000", color: "#fff" }}
      >
        العودة للرئيسية
      </a>
    </div>
  );
}
